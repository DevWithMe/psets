def main():
    time = str(input("Time: "))
    time_format = str(input("Format (DST or Regular): "))

    if time_format == "DST":
        print(dst_to_regular(time))
    else:
        print(regular_to_dst(time))

def dst_to_regular(time):
    pass

def regular_to_dst(time):
    pass

main()
